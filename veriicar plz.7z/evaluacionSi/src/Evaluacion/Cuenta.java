/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Evaluacion;

/**
 *
 * @author Victor Hernandez
 */
public class Cuenta {
    
    private int saldo;
    private int numero;
    private String titular;
    private String contraseña;
    
    public Cuenta(String contraseña,int numero, int saldo){
    this.contraseña=contraseña;
    this.numero=numero;
    this.saldo=saldo;
    
    }

    public void Giro() {
        int retiro = 0;

        saldo = (saldo - retiro) - 300;

    }

    
    public void mostrarSaldo(){
        
        System.out.println("su saldo es: "+ saldo);
    
    }
    
    public void deposito() {
        int deposito = 0;
        saldo = saldo + deposito;
    }
    


    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
}
