/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Evaluacion;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Victor Hernandez
 */
public class programa {

    public ArrayList<Cuenta> cuentas;

    public static void main(String[] args) {
        
        ArrayList cuenta = new ArrayList<>();
        cuenta.add(new Cuenta( "inacap", 0, 0));
        cuenta.add(new Cuenta( "inacap", 1, 0));
        cuenta.add(new Cuenta( "inacap", 2, 0));
        cuenta.add(new Cuenta( "inacap", 3, 0));
        cuenta.add(new Cuenta( "inacap", 4, 0));
        Scanner leer = new Scanner(System.in);
        String opc,con;
        int nc;
       
           
        System.out.println("ingrese en numero de cuenta");
        nc=leer.nextInt();
        System.out.println("ingrese contraseña");
        con=leer.next();
             
        for (int i = 0; i < 5; i++) {
            
        }
                    
               
          
    }

    /*
    Cuenta cnt = new Cuenta("Pepe", "inacap", 0, 0);
    Cuenta cnt1 = new Cuenta("carlos", "inacap", 1, 0);
    Cuenta cnt2 = new Cuenta("felipe", "inacap", 2, 0);
    Cuenta cnt3 = new Cuenta("max", "inacap", 3, 0);
    Cuenta cnt4 = new Cuenta("lalo", "inacap", 4, 0);
     */
}
